#!/usr/bin/env python3
import rospy
import actionlib
from robot_arm_actions.msg import PickPlaceAction, PickPlaceGoal
from geometry_msgs.msg import Pose

def feedback_cb(feedback):
    rospy.loginfo("Feedback: %s" % feedback.current_phase)

def pick_place_client():
    client = actionlib.SimpleActionClient('pick_place_server', PickPlaceAction)

    rospy.loginfo("Waiting for action server...")
    client.wait_for_server()

    rospy.loginfo("Action server found. Sending goal.")
    goal = PickPlaceGoal()
    goal.object_name = "Blue Cube"
    goal.target_pose.position.x = 1.5
    goal.target_pose.position.y = 2.0
    goal.target_pose.orientation.w = 1.0

    client.send_goal(goal, feedback_cb=feedback_cb)

    client.wait_for_result()
    
    result = client.get_result()
    rospy.loginfo("Final Result: %s" % result.message)

if __name__ == '__main__':
    try:
        rospy.init_node('pick_place_client')
        pick_place_client()
    except rospy.ROSInterruptException:
        rospy.loginfo("Program interrupted before completion")
