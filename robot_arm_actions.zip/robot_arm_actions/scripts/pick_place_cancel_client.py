#!/usr/bin/env python3
import rospy
import actionlib
from robot_arm_actions.msg import PickPlaceAction, PickPlaceGoal
from geometry_msgs.msg import Pose

def pick_place_cancel_client():
    client = actionlib.SimpleActionClient('pick_place_server', PickPlaceAction)

    rospy.loginfo("Waiting for action server...")
    client.wait_for_server()

    rospy.loginfo("Action server found. Sending goal.")
    goal = PickPlaceGoal(object_name="Red Cylinder")

    client.send_goal(goal)
    
    rospy.loginfo("Goal sent. Waiting 3 seconds before canceling...")
    rospy.sleep(3.0)
    
    rospy.loginfo("Canceling goal.")
    client.cancel_goal()

    client.wait_for_result()
    
    result = client.get_result()
    rospy.loginfo("Final Result: %s" % result.message)

if __name__ == '__main__':
    try:
        rospy.init_node('pick_place_cancel_client')
        pick_place_cancel_client()
    except rospy.ROSInterruptException:
        pass
