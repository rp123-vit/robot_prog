#!/usr/bin/env python3
import rospy
import actionlib
import time
from robot_arm_actions.msg import PickPlaceAction, PickPlaceFeedback, PickPlaceResult

class PickPlaceActionServer(object):
    def __init__(self, name):
        self._action_name = name
        self._as = actionlib.SimpleActionServer(self._action_name, PickPlaceAction, execute_cb=self.execute_cb, auto_start = False)
        self._as.start()
        rospy.loginfo("%s: Pick and Place Action Server is ready. 🤖" % self._action_name)

    def execute_cb(self, goal):
        rospy.loginfo("Executing goal to pick '%s' and place at target." % goal.object_name)
        
        # Helper variables
        feedback = PickPlaceFeedback()
        result = PickPlaceResult()
        
        # Simulate the phases of the task
        phases = ['Approaching object', 'Grasping object', 'Moving to destination', 'Releasing object']
        
        for i, phase in enumerate(phases):
            # Check if the client has requested to cancel the goal
            if self._as.is_preempt_requested():
                rospy.loginfo('%s: Preempted' % self._action_name)
                self._as.set_preempted()
                result.success = False
                result.message = "Task was canceled by user."
                # Note: We don't publish the result here, SimpleActionServer does it
                return

            # Publish feedback for the current phase
            feedback.current_phase = phase
            self._as.publish_feedback(feedback)
            rospy.loginfo("Feedback: %s" % phase)
            
            # Simulate time taken for this phase
            time.sleep(2.0)

        # If the loop completes without preemption, the goal is a success
        result.success = True
        result.message = "Successfully picked and placed %s." % goal.object_name
        rospy.loginfo('%s: Succeeded' % self._action_name)
        self._as.set_succeeded(result)

if __name__ == '__main__':
    rospy.init_node('pick_place_server')
    server = PickPlaceActionServer(rospy.get_name())
    rospy.spin()
