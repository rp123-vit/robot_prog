#!/usr/bin/env python3

import rospy
from ros_essentials.srv import SubtractTwoInts, SubtractTwoIntsResponse

def handle_subtract(req):
	ans_s = req.a - req.b
	return SubtractTwoIntsResponse(ans=ans_s)
	
def subtract_server():
	rospy.init_node('subtract_server_node')
	s = rospy.Service('subtract_service',SubtractTwoInts,handle_subtract)
	rospy.loginfo("Ready")
	rospy.spin()
	
if __name__ == '__main__':
	subtract_server()
