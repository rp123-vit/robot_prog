#!/usr/bin/env python3

import rospy
from std_msgs.msg import String

def simple_publisher():
	rospy.init_node('simple_publisher_node')
	pub = rospy.Publisher('chatter',String,queue_size=10)
	rate = rospy.Rate(2)
	message_to_publish = String()
	
	counter = 0
	rospy.loginfo("Publisher Node started, to chatter topic")
	
	while not rospy.is_shutdown():
		curr_time = "Hello World ABC! Message number %s" %counter
		message_to_publish.data = curr_time
		
		pub.publish(message_to_publish)
		rospy.loginfo(curr_time)
		counter+=1
		rate.sleep()

if __name__ == '__main__':
	try:
		simple_publisher()
	except rospy.ROSInterruptException:
		pass
	
	
	
	
	
	
	
	
	
	
