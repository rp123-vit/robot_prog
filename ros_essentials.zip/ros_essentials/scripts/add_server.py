#!/usr/bin/env python3

import rospy
from ros_essentials.srv import AddTwoInts, AddTwoIntsResponse

def handle_add(request):
	rospy.loginfo("Returning [%s+%s=%s]", request.a, request.b, (request.a+request.b))
	ans = request.a + request.b
	return AddTwoIntsResponse(sum=ans)
	
def add_server():
	rospy.init_node('add_server_node')
	s = rospy.Service('add_service',AddTwoInts, handle_add)
	rospy.loginfo("Ready to add")
	rospy.spin()
	
if __name__ == '__main__':
	add_server()
