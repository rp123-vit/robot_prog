#!/usr/bin/env python3

import sys
import rospy
from ros_essentials.srv import AddTwoInts, AddTwoIntsRequest

def add_client(x,y):
	rospy.wait_for_service('add_service')
	try:
		add_proxy = rospy.ServiceProxy('add_service', AddTwoInts)
		rospy.loginfo("Requesting %s+%s",x,y)
		response = add_proxy(x,y)
		return response.sum
	except rospy.ServiceException as e:
		print("Failed: %s",e)
		
if __name__ == '__main__':
	if len(sys.argv) == 3:
		x = int(sys.argv[1])
		y = int(sys.argv[2])
	else:
		sys.exit(1)
	
	result = add_client(x,y)
	print("Sum:",result)
