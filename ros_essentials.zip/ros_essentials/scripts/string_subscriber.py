#!/usr/bin/env python3

import rospy
from std_msgs.msg import String

def chatter_cb(msg):
	data_rec = msg.data
	rospy.loginfo("I heard: [%s]",data_rec.upper())
	
def simple_subscriber():
	rospy.init_node("Simple_subscriber")
	rospy.Subscriber('chatter',String,chatter_cb)
	rospy.loginfo("Listening")
	rospy.spin()
	
if __name__ == '__main__':
	simple_subscriber()
