#!/usr/bin/env python3

import sys
import rospy
from ros_essentials.srv import SubtractTwoInts, SubtractTwoIntsRequest

def subtract_client(x,y):
	rospy.wait_for_service('subtract_service')
	
	try:
		sp = rospy.ServiceProxy('subtract_service',SubtractTwoInts)
		response = sp(x,y)
		return response.ans
	except rospy.ServiceException as e:
		print(e)
		
if __name__ == '__main__':
	if len(sys.argv)==3:
		x = int(sys.argv[1])
		y = int(sys.argv[2])
	else:
		sys.exit(1)
		
	anss = subtract_client(x,y)
	print("Ans: ",anss)
