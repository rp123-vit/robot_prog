#!/usr/bin/env python3

import rospy
from std_msgs.msg import String

def chatter_cb2(msg):
	rospy.loginfo(msg.data)

def simple_sub():
	rospy.init_node("Simple_sub")
	rospy.Subscriber('chatter2',String,chatter_cb2)
	rospy.spin()
	
if __name__ == '__main__':
	simple_sub()
