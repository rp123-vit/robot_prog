#!/usr/bin/env python3

import rospy
from std_msgs.msg import String

def simple_publisher():
	rospy.init_node('Simple_Pub')
	pub = rospy.Publisher('chatter2',String,queue_size=10)
	rate = rospy.Rate(1)
	msg = String()
	
	counter = 0
	
	while not rospy.is_shutdown():
		curr = "msg: %s"%counter
		msg.data = curr
		
		pub.publish(msg)
		counter+=1
		rate.sleep()
		
if __name__ == '__main__':
	try:
		simple_publisher()
	except rospy.ROSInterruptException:
		pass
