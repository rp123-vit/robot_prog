#!usr/bin/env python3

import rospy
import time
import actionlib
from ros_essentials.msg import TimerAction, TimerFeedback, TimerResult

_as = None

def on_goal
